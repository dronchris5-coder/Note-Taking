-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2025 at 08:48 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mynote`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cID` int(11) NOT NULL,
  `ID` int(11) NOT NULL,
  `cName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cID`, `ID`, `cName`) VALUES
(52, 9, 'Memory'),
(53, 9, 'Personal'),
(54, 9, 'Testing'),
(57, 11, 'School'),
(59, 12, 'Goals'),
(60, 12, 'School'),
(61, 12, 'testing'),
(76, 1, 'Memory'),
(79, 1, 'Personal');

-- --------------------------------------------------------

--
-- Table structure for table `note_table`
--

CREATE TABLE `note_table` (
  `note_id` int(11) NOT NULL,
  `ID` int(11) NOT NULL,
  `cID` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `context` text NOT NULL,
  `created_date` datetime DEFAULT current_timestamp(),
  `updated_date` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_stared` tinyint(1) DEFAULT 0,
  `is_archieve` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `note_table`
--

INSERT INTO `note_table` (`note_id`, `ID`, `cID`, `title`, `context`, `created_date`, `updated_date`, `is_stared`, `is_archieve`) VALUES
(112, 6, NULL, 'Important', '<!-- Change Password Form -->\r\n  <div id=\"changePasswordForm\" class=\"change-password-form hidden\">\r\n    <form action=\"change_password.php\" method=\"POST\">\r\n      <h3>Change Password</h3>\r\n      <div class=\"form-group\">\r\n        <label for=\"oldPassword\">Old Password</label>\r\n        <input type=\"password\" id=\"oldPassword\" name=\"oldPassword\" required />\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"newPassword\">New Password</label>\r\n        <input type=\"password\" id=\"newPassword\" name=\"newPassword\" required />\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"confirmPassword\">Confirm New Password</label>\r\n        <input type=\"password\" id=\"confirmPassword\" name=\"confirmPassword\" required />\r\n      </div>\r\n      <div class=\"form-buttons\">\r\n        <button type=\"submit\" class=\"btn btn-change\">Change</button>\r\n        <button type=\"button\" class=\"btn btn-close\" onclick=\"toggleChangePasswordForm()\">Close</button>\r\n      </div>\r\n    </form>\r\n  </div>\r\n</div>', '2024-12-22 13:45:46', '2024-12-22 13:45:46', 1, 0),
(113, 6, NULL, 'Archive', '<!-- Change Password Form -->\r\n  <div id=\"changePasswordForm\" class=\"change-password-form hidden\">\r\n    <form action=\"change_password.php\" method=\"POST\">\r\n      <h3>Change Password</h3>\r\n      <div class=\"form-group\">\r\n        <label for=\"oldPassword\">Old Password</label>\r\n        <input type=\"password\" id=\"oldPassword\" name=\"oldPassword\" required />\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"newPassword\">New Password</label>\r\n        <input type=\"password\" id=\"newPassword\" name=\"newPassword\" required />\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"confirmPassword\">Confirm New Password</label>\r\n        <input type=\"password\" id=\"confirmPassword\" name=\"confirmPassword\" required />\r\n      </div>\r\n      <div class=\"form-buttons\">\r\n        <button type=\"submit\" class=\"btn btn-change\">Change</button>\r\n        <button type=\"button\" class=\"btn btn-close\" onclick=\"toggleChangePasswordForm()\">Close</button>\r\n      </div>\r\n    </form>\r\n  </div>\r\n</div>', '2024-12-22 13:46:13', '2024-12-22 13:46:13', 0, 1),
(114, 6, NULL, 'Scroll bar', '.view_textarea {\r\n    border: none;\r\n    font-size: 1rem;\r\n    height: 400px;\r\n    padding: 10px;\r\n    margin-left: 10px;\r\n    width: 100%;\r\n    margin-right: 10px;\r\n    padding-left: 10px;\r\n    resize: vertical;\r\n}', '2024-12-22 13:50:35', '2025-01-02 23:39:17', 0, 0),
(116, 6, NULL, 'Testing 1', '<?php if (isset($user[\'is_premium\']) && $user[\'is_premium\'] == 0): ?>\r\n        <button type=\"button\" class=\"btn btn-update\" onclick=\"window.location.href=\'payment.php\'\">Upgrade Plan $10</button>\r\n      <?php endif; ?>', '2024-12-22 13:42:24', '2025-01-02 23:38:34', 0, 0),
(118, 6, NULL, 'Memory', '<?php if (isset($user[\'is_premium\']) && $user[\'is_premium\'] == 0): ?>\r\n        <button type=\"button\" class=\"btn btn-update\" onclick=\"window.location.href=\'payment.php\'\">Upgrade Plan $10</button>\r\n      <?php endif; ?>', '2024-12-22 15:33:14', '2025-01-02 23:38:31', 0, 0),
(143, 1, NULL, 'Study Goals for 2025', '\"My study goals for this week include revising chapters 1 to 3, solving 10 practice problems daily, and watching tutorial videos on algebra.\"', '2024-12-28 02:20:24', '2025-11-29 03:23:43', 1, 0),
(155, 1, NULL, 'Recipe Note Pancake Recipe', '1 cup flour\r\n2 tbsp sugar\r\n1 tsp baking powder\r\n1 cup milk\r\n1 egg', '2024-12-28 02:15:40', '2025-11-06 14:30:58', 0, 0),
(157, 6, NULL, 'frfrf', '.view_textarea {\r\n    border: none;\r\n    font-size: 1rem;\r\n    height: 400px;\r\n    padding: 10px;\r\n    margin-left: 10px;\r\n    width: 100%;\r\n    margin-right: 10px;\r\n    padding-left: 10px;\r\n    resize: vertical;\r\n}', '2025-01-02 23:39:37', '2025-01-02 23:39:37', 0, 0),
(160, 9, NULL, 'yggugyug', 'utguhguthg', '2025-01-06 13:25:50', '2025-01-06 13:25:50', 0, 0),
(167, 1, NULL, 'To Do List', '\"Start the day with a morning workout, then attend the project meeting at 10 AM. Don\'t forget to submit the assignment by 3 PM, call mom in the evening, and read for 30 minutes before bed.\"', '2024-12-28 02:26:43', '2025-11-30 04:34:56', 0, 0),
(168, 13, NULL, 'Testing', 'bcure8i reyirefueroueorufryieryir ygityitryg', '2025-11-06 14:12:10', '2025-11-06 14:13:19', 1, 0),
(170, 13, NULL, 'uyryf', 'rrehr 77gbrt7gtr7gbo9trb7g9tr7bg9rto0vt0g0pviu uuruerut yt yetyer tyeruiy ueryt ue ryuery ui ee', '2025-11-06 14:13:49', '2025-11-06 14:17:20', 0, 0),
(171, 13, NULL, 'oi fobb5544 t', '8chb8t88t9v68vt9co8b9o8b9b866', '2025-11-06 14:16:15', '2025-11-06 14:16:15', 0, 0),
(172, 13, NULL, 'hhiuruihur', 'hrh4theuuvtu5tv45ut4', '2025-11-06 14:17:29', '2025-11-06 14:17:29', 0, 0),
(173, 13, NULL, 'ighthgu5hughugh5g', 'fihf8f85f54g7fg4gf4gf4g4', '2025-11-06 14:17:38', '2025-11-06 14:17:38', 0, 0),
(174, 13, NULL, 'unv5858vn558v585n854v4v44v', 'it5utvuu5vut9cu89565t', '2025-11-06 14:17:52', '2025-11-06 14:17:52', 0, 0),
(183, 1, NULL, 'Inspirational Quote 1.0', '\"The only way to do great work is to love what you do. This quote by Steve Jobs always motivates me to stay passionate about my goals.\"', '2024-12-28 02:17:12', '2025-12-02 14:38:52', 1, 1),
(185, 1, NULL, 'Work Goals for the Month', '\"This month, I aim to finish module development by Week 2, submit the testing report on time, and attend all scheduled team training sessions.\"', '2024-12-28 02:19:08', '2025-12-02 14:38:52', 1, 0),
(186, 1, NULL, 'Recipe Note', '\"To make pancakes, mix 1 cup of flour, 2 tablespoons of sugar, 1 teaspoon of baking powder, 1 cup of milk, and 1 egg. Cook the mixture on medium heat and serve with syrup for a delightful breakfast.\"', '2024-12-28 02:18:00', '2025-12-02 14:38:52', 1, 1),
(189, 1, NULL, 'Testing Archive', 'Testing 12345', '2025-11-25 02:50:16', '2025-12-02 14:38:52', 1, 1),
(212, 1, NULL, 'tesingndklfe', 'hjhewrhrehic', '2025-12-01 16:26:01', '2025-12-02 15:07:53', 1, 1),
(213, 1, NULL, 'Favorite Movies List', '\"Some of my favorite movies are \'Inception,\' \'The Shawshank Redemption,\' \'The Matrix,\' \'Interstellar,\' and \'The Grand Budapest Hotel.\'\"', '2024-12-28 02:20:50', '2025-11-23 23:20:40', 0, 0),
(215, 1, NULL, 'Final Testing', 'Final Testing\r\nFinal Testing\r\nFinal Testing', '2025-12-02 14:22:46', '2025-12-02 15:07:53', 1, 1),
(219, 1, NULL, 'Testing Final 2.0', 'Testing Final 2.0\r\nTesting Final 2.0\r\nTesting Final 2.0', '2025-12-02 14:35:10', '2025-12-02 15:07:53', 1, 1),
(220, 15, NULL, 'testing', 'testing', '2025-12-02 15:15:07', '2025-12-02 15:15:07', 0, 0),
(221, 15, NULL, 'testing', 'testing', '2025-12-02 15:15:13', '2025-12-02 15:15:13', 0, 0),
(222, 15, NULL, 'testing', 'testing', '2025-12-02 15:15:18', '2025-12-02 15:15:18', 0, 0),
(223, 15, NULL, 'testing', 'testing', '2025-12-02 15:15:22', '2025-12-02 15:15:22', 0, 0),
(224, 15, NULL, 'testing', 'testing', '2025-12-02 15:15:26', '2025-12-02 15:15:26', 0, 0),
(225, 15, NULL, 'testing', 'testing', '2025-12-02 15:15:30', '2025-12-02 15:15:30', 0, 0),
(226, 15, NULL, 'testing', 'testing', '2025-12-02 15:15:37', '2025-12-02 15:15:37', 0, 0),
(227, 15, NULL, 'testing', 'testing', '2025-12-02 15:15:41', '2025-12-02 15:15:41', 0, 0),
(228, 15, NULL, 'testing', 'testing', '2025-12-02 15:15:45', '2025-12-02 15:15:45', 0, 0),
(229, 15, NULL, 'testing', 'testing', '2025-12-02 15:15:49', '2025-12-02 15:15:49', 0, 0),
(230, 15, NULL, 'testing', 'testing', '2025-12-02 15:16:31', '2025-12-02 15:16:31', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `share_table`
--

CREATE TABLE `share_table` (
  `share_id` int(11) NOT NULL,
  `note_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `shared_to_id` int(11) NOT NULL,
  `shared_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `share_table`
--

INSERT INTO `share_table` (`share_id`, `note_id`, `owner_id`, `shared_to_id`, `shared_date`) VALUES
(13, 212, 1, 14, '2025-12-01 16:27:16'),
(14, 185, 1, 14, '2025-12-01 16:27:27'),
(15, 212, 1, 14, '2025-12-01 16:29:13'),
(16, 212, 14, 14, '2025-12-01 16:29:47'),
(17, 185, 1, 14, '2025-12-01 16:31:06');

-- --------------------------------------------------------

--
-- Table structure for table `trash_table`
--

CREATE TABLE `trash_table` (
  `trash_id` int(11) NOT NULL,
  `ID` int(11) NOT NULL,
  `cID` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `context` text NOT NULL,
  `created_date` datetime DEFAULT current_timestamp(),
  `updated_date` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_stared` tinyint(1) DEFAULT 0,
  `is_archieve` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trash_table`
--

INSERT INTO `trash_table` (`trash_id`, `ID`, `cID`, `title`, `context`, `created_date`, `updated_date`, `is_stared`, `is_archieve`) VALUES
(29, 6, NULL, 'Hello 1', '<!-- Change Password Form -->\r\n  <div id=\"changePasswordForm\" class=\"change-password-form hidden\">\r\n    <form action=\"change_password.php\" method=\"POST\">\r\n      <h3>Change Password</h3>\r\n      <div class=\"form-group\">\r\n        <label for=\"oldPassword\">Old Password</label>\r\n        <input type=\"password\" id=\"oldPassword\" name=\"oldPassword\" required />\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"newPassword\">New Password</label>\r\n        <input type=\"password\" id=\"newPassword\" name=\"newPassword\" required />\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"confirmPassword\">Confirm New Password</label>\r\n        <input type=\"password\" id=\"confirmPassword\" name=\"confirmPassword\" required />\r\n      </div>\r\n      <div class=\"form-buttons\">\r\n        <button type=\"submit\" class=\"btn btn-change\">Change</button>\r\n        <button type=\"button\" class=\"btn btn-close\" onclick=\"toggleChangePasswordForm()\">Close</button>\r\n      </div>\r\n    </form>\r\n  </div>\r\n</div>', '2024-12-22 13:45:11', '2024-12-22 13:45:11', 0, 0),
(30, 6, NULL, 'Testing 4', '<!-- Change Password Form -->\r\n  <div id=\"changePasswordForm\" class=\"change-password-form hidden\">\r\n    <form action=\"change_password.php\" method=\"POST\">\r\n      <h3>Change Password</h3>\r\n      <div class=\"form-group\">\r\n        <label for=\"oldPassword\">Old Password</label>\r\n        <input type=\"password\" id=\"oldPassword\" name=\"oldPassword\" required />\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"newPassword\">New Password</label>\r\n        <input type=\"password\" id=\"newPassword\" name=\"newPassword\" required />\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"confirmPassword\">Confirm New Password</label>\r\n        <input type=\"password\" id=\"confirmPassword\" name=\"confirmPassword\" required />\r\n      </div>\r\n      <div class=\"form-buttons\">\r\n        <button type=\"submit\" class=\"btn btn-change\">Change</button>\r\n        <button type=\"button\" class=\"btn btn-close\" onclick=\"toggleChangePasswordForm()\">Close</button>\r\n      </div>\r\n    </form>\r\n  </div>\r\n</div>', '2024-12-22 13:43:08', '2024-12-22 13:43:08', 0, 0),
(31, 6, NULL, 'Home', '<!-- Change Password Form -->\r\n  <div id=\"changePasswordForm\" class=\"change-password-form hidden\">\r\n    <form action=\"change_password.php\" method=\"POST\">\r\n      <h3>Change Password</h3>\r\n      <div class=\"form-group\">\r\n        <label for=\"oldPassword\">Old Password</label>\r\n        <input type=\"password\" id=\"oldPassword\" name=\"oldPassword\" required />\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"newPassword\">New Password</label>\r\n        <input type=\"password\" id=\"newPassword\" name=\"newPassword\" required />\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"confirmPassword\">Confirm New Password</label>\r\n        <input type=\"password\" id=\"confirmPassword\" name=\"confirmPassword\" required />\r\n      </div>\r\n      <div class=\"form-buttons\">\r\n        <button type=\"submit\" class=\"btn btn-change\">Change</button>\r\n        <button type=\"button\" class=\"btn btn-close\" onclick=\"toggleChangePasswordForm()\">Close</button>\r\n      </div>\r\n    </form>\r\n  </div>\r\n</div>', '2024-12-22 13:43:47', '2024-12-22 13:44:09', 0, 0),
(32, 6, NULL, 'Testing 3', '<!-- Change Password Form -->\r\n  <div id=\"changePasswordForm\" class=\"change-password-form hidden\">\r\n    <form action=\"change_password.php\" method=\"POST\">\r\n      <h3>Change Password</h3>\r\n      <div class=\"form-group\">\r\n        <label for=\"oldPassword\">Old Password</label>\r\n        <input type=\"password\" id=\"oldPassword\" name=\"oldPassword\" required />\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"newPassword\">New Password</label>\r\n        <input type=\"password\" id=\"newPassword\" name=\"newPassword\" required />\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"confirmPassword\">Confirm New Password</label>\r\n        <input type=\"password\" id=\"confirmPassword\" name=\"confirmPassword\" required />\r\n      </div>\r\n      <div class=\"form-buttons\">\r\n        <button type=\"submit\" class=\"btn btn-change\">Change</button>\r\n        <button type=\"button\" class=\"btn btn-close\" onclick=\"toggleChangePasswordForm()\">Close</button>\r\n      </div>\r\n    </form>\r\n  </div>\r\n</div>', '2024-12-22 13:42:56', '2024-12-22 13:42:56', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `ID` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `is_premium` tinyint(4) DEFAULT 0,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Age` int(11) DEFAULT NULL,
  `Country` varchar(100) NOT NULL,
  `State` varchar(100) NOT NULL,
  `City` varchar(100) NOT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`ID`, `Email`, `Password`, `is_premium`, `FirstName`, `LastName`, `Username`, `Gender`, `Age`, `Country`, `State`, `City`, `Image`, `reset_token`, `token_expiry`) VALUES
(1, 'testing@gmail.com', '$2y$10$X9g8lYuFTXp1Sr/dKu5zaeMW8CPs2ACuhNR5sgxc63rz9AiqIRw7u', 1, 'Kaung Sint', 'Thu', 'Testing', 'Female', 18, 'Singapore', 'Yangon1.0', 'Yangon', '1764659542_logo.jpg', NULL, NULL),
(6, 'testing5@gmail.com', '$2y$10$4tkyHsg.J1ARMC1z4/E.YOX9sf0t3.1nJTqFDiREExopes853D1T2', 1, 'Kaung Sint', 'Thu', 'Testing5', 'Male', 18, 'Myanmar', '', '', './uploads/profile_6_1734856839.jpg', NULL, NULL),
(9, 'kkk@gmail.com', '$2y$10$Q9gsq9W82szjAD1uTpX7gu58NQtz4fFEOTSCF2baA00Hk0syOJc46', 1, '', '', 'kkk', '', NULL, '', '', '', NULL, NULL, NULL),
(10, 'testing0@gmail.com', '$2y$10$Do/jIOjq.pW.jQ3WiZXO/e6q0X3V.9pvBQbgy0NxQ1eufjiG3PXBu', 0, '', '', 'testing0', '', NULL, '', '', '', NULL, NULL, NULL),
(11, 'testing2.0@gmail.com', '$2y$10$FP1q0xY/Xr1jwXFvib4MXuTjdzQbLFLtIYqpFDlWHWCpQ1jbOAcuO', 0, '', '', 'testing2.0', '', NULL, '', '', '', NULL, NULL, NULL),
(12, 'testing4.0@gmail.com', '$2y$10$XLB0dS65e1GFavPdmBWlqOO/qWgVvQdwp8RHxzKp5qjghxKyj1xfW', 1, '', '', 'testing4.0', '', NULL, '', '', '', NULL, NULL, NULL),
(13, 'hein@gmail.com', '$2y$10$7stUz0NjVmArpjht2qnBdusbuZ53D0fPxfppSjj/NH3N5nwG5zwUO', 1, '', '', 'Hein', '', NULL, '', '', '', NULL, NULL, NULL),
(14, 'kaungsintthu13@gmail.com', '$2y$10$WfT/flL8U1naBtHNPBp1l.WE5cpVFwMnW.nf5z06sIhcAo3fDYYF6', 1, '', '', 'Excalibur', '', NULL, '', '', '', NULL, NULL, NULL),
(15, 'kaungsintthusg@gmail.com', '$2y$10$5SB/ITIaq3ImU2hwhkjvEe17Uf1d4frWlzFdVmGEajABJRvkpidkC', 1, '', '', 'Kaung Sint Thu', '', NULL, '', '', '', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cID`),
  ADD KEY `ID` (`ID`);

--
-- Indexes for table `note_table`
--
ALTER TABLE `note_table`
  ADD PRIMARY KEY (`note_id`),
  ADD KEY `ID` (`ID`),
  ADD KEY `cID` (`cID`);

--
-- Indexes for table `share_table`
--
ALTER TABLE `share_table`
  ADD PRIMARY KEY (`share_id`),
  ADD KEY `note_id` (`note_id`),
  ADD KEY `owner_id` (`owner_id`),
  ADD KEY `shared_to_id` (`shared_to_id`);

--
-- Indexes for table `trash_table`
--
ALTER TABLE `trash_table`
  ADD PRIMARY KEY (`trash_id`),
  ADD KEY `ID` (`ID`),
  ADD KEY `cID` (`cID`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `note_table`
--
ALTER TABLE `note_table`
  MODIFY `note_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- AUTO_INCREMENT for table `share_table`
--
ALTER TABLE `share_table`
  MODIFY `share_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `trash_table`
--
ALTER TABLE `trash_table`
  MODIFY `trash_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `category`
--
ALTER TABLE `category`
  ADD CONSTRAINT `category_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `user_table` (`ID`) ON DELETE CASCADE;

--
-- Constraints for table `note_table`
--
ALTER TABLE `note_table`
  ADD CONSTRAINT `note_table_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `user_table` (`ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `note_table_ibfk_2` FOREIGN KEY (`cID`) REFERENCES `category` (`cID`) ON DELETE SET NULL;

--
-- Constraints for table `share_table`
--
ALTER TABLE `share_table`
  ADD CONSTRAINT `share_table_ibfk_1` FOREIGN KEY (`note_id`) REFERENCES `note_table` (`note_id`),
  ADD CONSTRAINT `share_table_ibfk_2` FOREIGN KEY (`owner_id`) REFERENCES `user_table` (`ID`),
  ADD CONSTRAINT `share_table_ibfk_3` FOREIGN KEY (`shared_to_id`) REFERENCES `user_table` (`ID`);

--
-- Constraints for table `trash_table`
--
ALTER TABLE `trash_table`
  ADD CONSTRAINT `trash_table_ibfk_2` FOREIGN KEY (`ID`) REFERENCES `user_table` (`ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `trash_table_ibfk_3` FOREIGN KEY (`cID`) REFERENCES `category` (`cID`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
